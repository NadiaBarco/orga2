#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <argp.h>

#include "utils.h"
#include "ej2.h"


int main (int argc, char *argv[]) {
	/* Acá pueden realizar sus propias pruebas */
	return 0;  
}


#include "ej2.h"


void maximosYMinimos(uint8_t *src, uint8_t *dst, uint32_t width, uint32_t height) {

}

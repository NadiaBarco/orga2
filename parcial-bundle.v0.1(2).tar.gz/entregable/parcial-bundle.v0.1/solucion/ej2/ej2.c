#include "ej2.h"

/**
 * Marca el ejercicio 2 como hecho (`true`) o pendiente (`false`).
 *
 * Funciones a implementar:
 *   - ej2
 */
bool EJERCICIO_2_HECHO = false;

/**
 * Dadas dos imágenes de origen (`a` y `b`) en conjunto con sus mapas de
 * profundidad escribe en el destino el pixel de menor profundidad por cada
 * píxel de la imagen. En caso de empate se escribe el píxel de `b`.
 *
 * Parámetros:
 *   - dst:     La imagen destino. Está a color (RGBA) en 8 bits sin signo por
 *              canal.
 *   - a:       La imagen origen A. Está a color + profundidad (RGBD) en 8 bits
 *              sin signo por canal.
 *   - a:       La imagen origen B. Está a color + profundidad (RGBD) en 8 bits
 *              sin signo por canal.
 *   - width:  El ancho en píxeles las imágenes parámetro.
 *   - height: El alto en píxeles las imágenes parámetro.
 */
void ej2(rgba_t* dst, rgbd_t* a, rgbd_t* b, uint32_t width, uint32_t height) {
}

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#include "ej2.h"

/**
 * Forma de especificarle a `load_image` que no nos importa la cantidad de
 * canales de una imagen.
 */
#define ANY_CHANNEL_COUNT 0
/**
 * Cantidad de canales en un mapa de profundidad
 */
#define DEPTH_CHANNEL_COUNT 1
/**
 * Cantidad de canales en una imagen RGBA
 */
#define RGBA_CHANNEL_COUNT 4

/**
 * Una imagen.
 *
 * Campos:
 *   - width:                  El ancho de la imagen. Es positivo.
 *   - height:                 El alto de la imagen. Es positivo.
 *   - original_channel_count: La cantidad de canales de la imagen fuente.
 *   - channel_count:          La cantidad de canales (de 8 bits) cargados a
 *                             memoria.
 *   - data:                   Un buffer de (width * height * channel_count)
 *                             bytes que tiene los píxeles de la imagen.
 */
typedef struct img {
	int width;
	int height;
	int original_channel_count;
	int channel_count;
	uint8_t* data;
} img_t;

/**
 * Carga una imagen.
 *
 * Parámetros:
 *   - filepath:         Ruta del sistema de archivos en dónde se encuentra la
 *                       imagen.
 *   - desired_channels: Cantidad de canales a esperar encontrar en la imagen.
 *                       Cero representa _"no sé"_.
 */
static img_t load_image(const char* filepath, int desired_channels) {
	img_t result;
	result.data = stbi_load(
		filepath,
		&result.width,
		&result.height,
		&result.original_channel_count,
		desired_channels
	);
	result.channel_count = desired_channels;
	return result;
}

/**
 * Convierte un mapa de profundidad de 8 bits sin signo a 32 bits con signo.
 *
 * Parámetros:
 *   - dst:    Imagen destino. 32 bits con signo por píxel.
 *   - src:    Imagen fuente. 8 bits sin signo por píxel.
 *   - width:  Ancho de la imagen. Debe ser positivo.
 *   - height: Alto de la imagen. Debe ser positivo.
 */
static void rgbd_from_uint8_and_rgba(
	rgbd_t* dst,
	rgba_t* color_src,
	uint8_t* depth_src,
	uint32_t width, uint32_t height
) {
	for (uint32_t y = 0; y < height; y++) {
		for (uint32_t x = 0; x < width; x++) {
			uint32_t i = y * width + x;
			dst[i].r = color_src[i].r;
			dst[i].g = color_src[i].g;
			dst[i].b = color_src[i].b;
			dst[i].d = depth_src[i];
		}
	}
}

/**
 * Tamaño máximo soportado para rutas del sistema de archivos
 */
#define MAX_FILEPATH_SIZE 127

/**
 * Construye una ruta en el sistema operativo por medio de agregarle un prefijo
 * y un sufijo a un nombre dado.
 *
 * Parámetros:
 *   - filepath: Buffer en dónde escribir el resultado.
 *   - prefix:   Texto a poner al principio de la ruta.
 *   - name:     Texto a poner en el medio de la ruta. Es algún tipo de nombre.
 *   - suffix:   Texto a poner al final de la ruta. Normalmente es una
 *               extensión.
 */
void build_filepath(char filepath[MAX_FILEPATH_SIZE + 1], const char* prefix, const char* name, const char* suffix) {
	filepath[0] = 0;
	strncat(filepath, prefix, MAX_FILEPATH_SIZE);
	strncat(filepath, name, MAX_FILEPATH_SIZE);
	strncat(filepath, suffix, MAX_FILEPATH_SIZE);
}

/**
 * Cuenta cuántos tests corrieron exitosamente.
 */
uint64_t successful_tests = 0;
/**
 * Cuenta cuántos tests test fallaron.
 */
uint64_t failed_tests = 0;

/**
 * El mensaje [DONE] escrito en verde.
 */
#define DONE "[\033[32;1mDONE\033[0m] "

/**
 * El mensaje [FAIL] escrito en rojo.
 */
#define FAIL "[\033[31;1mFAIL\033[0m] "

/**
 * El mensaje [SKIP] escrito en magenta.
 */
#define SKIP "[\033[95;1mSKIP\033[0m] "

/**
 * Compara un resultado con la imagen esperada. Devuelve `true` si encuentra
 * diferencias.
 *
 * Parámetros:
 *   - name:        Nombre del test.
 *   - buffer:      Resultado a comparar.
 *   - buffer_size: Tamaño en bytes del resultado a comparar.
 */
bool has_differences(const char* name, void* buffer, uint64_t buffer_size) {
	bool result = false;
	char filepath[MAX_FILEPATH_SIZE + 1];
	build_filepath(filepath, "expected/", name, ".png");

	img_t expected = load_image(filepath, ANY_CHANNEL_COUNT);
	uint64_t expected_data_size = expected.width * expected.height * expected.original_channel_count;

	if (buffer_size != expected_data_size) {
		result = true;
	} else if (memcmp(buffer, expected.data, buffer_size) != 0) {
		result = true;
	}

	stbi_image_free(expected.data);
	return result;
}

/**
 * Corre un test del ejercicio 2.
 *
 * Parámetros:
 *   - name_out: Nombre del test.
 *   - name_a:   Nombre de la imagen de entrada A.
 *   - name_b:   Nombre de la imagen de entrada B.
 */
void do_test(
	const char* name_out,
	const char* name_a,
	const char* name_b
) {
	uint64_t failed_at_start = failed_tests;
	if (!EJERCICIO_2_HECHO) {
		printf(SKIP "El ejercicio 2B no está hecho aún.\n");
		return;
	}

	char filepath_a[MAX_FILEPATH_SIZE + 1];
	build_filepath(filepath_a, "img/", name_a, ".png");

	char filepath_b[MAX_FILEPATH_SIZE + 1];
	build_filepath(filepath_b, "img/", name_b, ".png");

	char depth_filepath_a[MAX_FILEPATH_SIZE + 1];
	build_filepath(depth_filepath_a, "img/depth/", name_a, ".png");

	char depth_filepath_b[MAX_FILEPATH_SIZE + 1];
	build_filepath(depth_filepath_b, "img/depth/", name_b, ".png");

	char filepath_out[MAX_FILEPATH_SIZE + 1];
	build_filepath(filepath_out, "outputs/", name_out, ".png");

	img_t a = load_image(filepath_a, RGBA_CHANNEL_COUNT);
	img_t b = load_image(filepath_b, RGBA_CHANNEL_COUNT);
	img_t depth_a = load_image(depth_filepath_a, DEPTH_CHANNEL_COUNT);
	img_t depth_b = load_image(depth_filepath_b, DEPTH_CHANNEL_COUNT);

	assert(a.width == b.width && a.width == depth_a.width && a.width == depth_b.width);
	assert(a.height == b.height && a.height == depth_a.height && a.height == depth_b.height);

	uint32_t width = a.width;
	uint32_t height = a.height;
	uint64_t out_size = width * height * sizeof(rgba_t);
	rgba_t* out = malloc(out_size);
	rgbd_t* a_with_depth = malloc(width * height * sizeof(rgbd_t));
	rgbd_t* b_with_depth = malloc(width * height * sizeof(rgbd_t));

	rgbd_from_uint8_and_rgba(
		a_with_depth,
		(rgba_t*) a.data,
		depth_a.data,
		width, height
	);
	rgbd_from_uint8_and_rgba(
		b_with_depth,
		(rgba_t*) b.data,
		depth_b.data,
		width, height
	);
	ej2(out, a_with_depth, b_with_depth, width, height);
	stbi_write_png(
		filepath_out,
		width, height,
		RGBA_CHANNEL_COUNT,
		out,
		width * sizeof(rgba_t)
	);
	if (has_differences(name_out, out, out_size)) {
		printf(FAIL "do_test(\"%s\", \"%s\", \"%s\")\n", name_out, name_a, name_b);
		printf(FAIL "  Se encontraron diferencias:\n");
		printf(FAIL "    Imagen de entrada A: %s\n", filepath_a);
		printf(FAIL "    Imagen de entrada B: %s\n", filepath_b);
		printf(FAIL "    Mapa de profundidad A: %s\n", depth_filepath_a);
		printf(FAIL "    Mapa de profundidad B: %s\n", depth_filepath_b);
		printf(FAIL "    Imagen de salida: %s\n", filepath_out);
		printf(FAIL "    Imagen de salida esperada: expected/%s.png\n", name_out);
		printf(FAIL "\n");
		failed_tests++;
	} else {
		printf(DONE "do_test(\"%s\", \"%s\", \"%s\")\n", name_out, name_a, name_b);
		successful_tests++;
	}

	free(out);
	free(a_with_depth);
	free(b_with_depth);
	stbi_image_free(a.data);
	stbi_image_free(b.data);
	stbi_image_free(depth_a.data);
	stbi_image_free(depth_b.data);
}

/**
 * Evalúa los tests del ejercicio 2. Este ejercicio requiere implementar
 * `ej2`.
 *
 * Si algún test falla el programa va a terminar con un código de error.
 */
int main(int argc, char* argv[]) {
	uint64_t failed_at_start = failed_tests;

	do_test("1", "martini1841",     "mascotas");
	do_test("2", "grim",            "grim-flip");
	do_test("3", "grim/me_0_carla", "grim/me_1_pmpws");
	do_test("4", "grim/re_1_front", "grim/jb_0_garin");
	do_test("5", "grim/ei_1_intha", "grim/ei_1_intha-flip");
	do_test("6", "grim/dr_0_winws", "grim/dr_1_dorrv");
	do_test("7", "grim/ci_0_stpws", "grim/hl_0_dorrv");
	do_test("8", "grim/tw_0_trkvw", "grim/le_2_ladws");
	do_test("9", "grim/SP_1_ENTLA", "grim/tr_2_pmpws");

	if (failed_at_start < failed_tests) {
		printf(FAIL "El ejercicio 2 tuvo tests que fallaron.\n");
	}

	printf(
		"\nSe corrieron %ld tests. %ld corrieron exitosamente. %ld fallaron.\n",
		failed_tests + successful_tests, successful_tests, failed_tests
	);

	if (failed_tests) {
		return 1;
	} else {
		return 0;
	}
}

#pragma once
#include <stdbool.h>
#include <stdint.h>

/**
 * Un píxel RGBA.
 *
 * Campos:
 *   - r: La cantidad de rojo en el píxel. Va de 0 a 255.
 *   - g: La cantidad de verde en el píxel. Va de 0 a 255.
 *   - b: La cantidad de azul en el píxel. Va de 0 a 255.
 *   - a: La transparencia del píxel. Va de 0 a 255.
 */
typedef struct rgba_pixfmt {
	uint8_t r;
	uint8_t g;
	uint8_t b;
	uint8_t a;
} rgba_t;

/**
 * Un píxel RGBD.
 *
 * Campos:
 *   - r: La cantidad de rojo en el píxel. Va de 0 a 255.
 *   - g: La cantidad de verde en el píxel. Va de 0 a 255.
 *   - b: La cantidad de azul en el píxel. Va de 0 a 255.
 *   - d: La profundidad del píxel. Va de 0 a 255.
 */
typedef struct rgbd_pixfmt {
	uint8_t r;
	uint8_t g;
	uint8_t b;
	uint8_t d;
} rgbd_t;

/**
 * Marca el ejercicio 2 como hecho (`true`) o pendiente (`false`).
 *
 * Funciones a implementar:
 *   - ej2
 */
extern bool EJERCICIO_2_HECHO;

/**
 * Dadas dos imágenes de origen (`a` y `b`) en conjunto con sus mapas de
 * profundidad escribe en el destino el pixel de menor profundidad por cada
 * píxel de la imagen. En caso de empate se escribe el píxel de `b`.
 *
 * Parámetros:
 *   - dst:     La imagen destino. Está a color (RGBA) en 8 bits sin signo por
 *              canal.
 *   - a:       La imagen origen A. Está a color + profundidad (RGBD) en 8 bits
 *              sin signo por canal.
 *   - a:       La imagen origen B. Está a color + profundidad (RGBD) en 8 bits
 *              sin signo por canal.
 *   - width:  El ancho en píxeles las imágenes parámetro.
 *   - height: El alto en píxeles las imágenes parámetro.
 */
void ej2(rgba_t* dst, rgbd_t* a, rgbd_t* b, uint32_t width, uint32_t height);
